﻿using System;
using System.Linq;
using Driver;
using Passenger;
using Ride;
using Admin;
using Vehicle;
using Location;
using System.Collections.Generic;
namespace MyRidingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t\t\t\tWELCOME TO MYRIDE");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------\n\n");
            Console.WriteLine("1.  Book a Ride");
            Console.WriteLine("2.  Enter as Driver");
            Console.WriteLine("3.  Enter as Admin\n\n");
            Console.Write("Choose your  option :");
            int select = Convert.ToInt32(Console.ReadLine());
            switch(select)
            {
                case 1:
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("\t\t\t\t\t\t\tWELCOME, YOU WANT TO BOOK A RIDE");
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------\n\n");
                    Passengerclass p = new Passengerclass();
                    Console.Write("Enter Name: ");
                    p.Myname = Console.ReadLine();
                    Console.Write("Enter Phone No: ");
                    p.Myphone_no = Console.ReadLine();
                    // p.bookRide();
                    Console.Write("Enter Ride Type :");
                    p.Mytype = Console.ReadLine();
                    Rideclass r = new Rideclass();
                    string ride_type = p.Mytype;
                    switch (ride_type)
                    {
                        case "bike":
                          
                            int price_of_ride = r.calculate_Price_bike();
                            Console.WriteLine("Price of this ride is :" + price_of_ride);
                            Console.WriteLine("----------------------THANK YOU-----------------------");
                            p.about();
                            break;
                        case "rickshah":
                           
                            int price_of_ride_for_rickshah = r.calculate_Price_rickshah();
                            Console.WriteLine("Price of this ride is :" + price_of_ride_for_rickshah);
                            Console.WriteLine("----------------------THANK YOU-----------------------");
                            p.about();
                            break;
                        case "car":
                            
                            int price_of_ride_for_car = r.calculate_Price_car();
                            Console.WriteLine("Price of this ride is :" + price_of_ride_for_car);
                            Console.WriteLine("----------------------THANK YOU-----------------------");
                            p.about();
                            break;
                    }

                    break;


                case 2:
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("\t\t\t\t\t\t\tWELCOME, YOU ENTERED AS A DRIVER");
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------\n\n");
                    Driverclass d = new Driverclass();
                    List<string> driver = new List<string>();
                    driver.Add("ali");
                    driver.Add("shahbaz");
                    driver.Add("nomi");
                    driver.Add("imran");
                    driver.Add("ansar");
                    driver.Add("sarfaraz");

                    Console.Write("Enter your name :");
                    d.Myname = Console.ReadLine();
                    if (driver.Contains(d.Myname))
                    {
                        Console.WriteLine("Hello  " + d.Myname + "!");
                        d.curr_location();

                        Console.WriteLine("1.  Change availability");
                        Console.WriteLine("2.  Change Location ");
                        Console.WriteLine("3.  Exit as Driver");
                        int choose = Convert.ToInt32(Console.ReadLine());
                        switch(choose)
                        {
                            case 1:
                                d.upadetAvailability();
                                break;
                            case 2:
                                d.updateLocation();
                                break;
                            case 3:
                                
                                break;
                        }

                    }
                    else
                        Console.WriteLine("You are not registered as a Driver");
                    break;
                case 3:
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("\t\t\t\t\t\t\tWELCOME, YOU ENTERED AS A ADMIN");
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------\n\n");
                    Console.WriteLine("1.  Add Driver");
                    Console.WriteLine("2.  Remove Driver");
                   // Console.WriteLine("3.  Update Driver");
                   // Console.WriteLine("4.  Search Driver");
                    Console.WriteLine("3.  Exit as Admin");
                    Adminclass a = new Adminclass();
                    //a.addDriver();
                    int choos = Convert.ToInt32(Console.ReadLine());
                    switch (choos)
                    {
                        case 1:
                            a.addDriver();
                            break;
                        case 2:
                            a.RemoveDriver();
                            break;
                        case 5:

                            break;
                    }


                    break;

                    Console.ReadLine();
            }

          




           
            Console.ReadLine();
        }
    }
}
